package com.example.conversordemonedas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //Definir objetos
    private EditText PRECIODEBITCOIN;
    private TextView Result;
    Button ACCION;
    Spinner SpinSelect;
    //opciones del spinner String o(^▽^)o
    String[] MyLista ={"Dólares", "Quetzales", "Lempiras", "Cólones Costarricenses", "Córdobas"};
    private static final double DOLLAR_EXCHANGE_RATE = 1.0;
    private static final double LEMPIRA_EXCHANGE_RATE = 24.63;
    private static final double QUETZAL_EXCHANGE_RATE = 7.84;
    private static final double CORDOBA_EXCHANGE_RATE = 36.52;
    private static final double COLON_EXCHANGE_RATE = 578.51;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SpinSelect = findViewById(R.id.SpinSelect);
        PRECIODEBITCOIN = findViewById(R.id.BitcoinPrice);
        Result = findViewById(R.id.Resultado);
        ACCION = findViewById(R.id.btnAccion);
        ArrayAdapter<String> Predator = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,MyLista);
        SpinSelect.setAdapter(Predator);
        ACCION = findViewById(R.id.btnAccion);
        ACCION.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calcular();
            }
        });
    }
    public void Calcular(){
        String bitcoinPriceString = PRECIODEBITCOIN.getText().toString();
        //Asignar eventos
        if (bitcoinPriceString.isEmpty()){
            Toast.makeText(MainActivity.this, "Ingrese el precio y la cantidad de Bitcoin", Toast.LENGTH_SHORT).show();
        } else {
            double bitcoinPrice = Double.parseDouble(bitcoinPriceString);
            double dollarAmount = bitcoinPrice * DOLLAR_EXCHANGE_RATE;
            double lempiraAmount = bitcoinPrice * LEMPIRA_EXCHANGE_RATE;
            double quetzalAmount = bitcoinPrice * QUETZAL_EXCHANGE_RATE;
            double cordobaAmount = bitcoinPrice *  CORDOBA_EXCHANGE_RATE;
            double colonAmount1 = bitcoinPrice *  COLON_EXCHANGE_RATE;
            String resultString;
            resultString = SpinSelect.getSelectedItem().toString();
            if(resultString.equals("Dólares")){
                Result.setText(""+dollarAmount);
            } else if (resultString.equals("Lempiras")) {
                Result.setText(""+lempiraAmount);
            } else if (resultString.equals("Quetzales")) {
                Result.setText(""+quetzalAmount);
            } else if (resultString.equals("Córdobas")) {
                Result.setText(""+cordobaAmount);
            } else if (resultString.equals("Cólones Costarricenses")) {
                Result.setText(""+colonAmount1);
            }
        }
    }
}

